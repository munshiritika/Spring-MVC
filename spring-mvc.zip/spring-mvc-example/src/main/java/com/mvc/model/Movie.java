package com.mvc.model;
//02-13-2024, Tuesday
import lombok.Data;

@Data
public class Movie {	
	private int movieId;
	private String movieName;
	private int years;
	private String duration;
	private int rating;

}
