package com.mvc.main;
//02-15-2024, Thursday
import java.util.Scanner;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import com.mvc.controller.MovieController;
import com.mvc.model.Movie;

public class SaveMovieMain {
	
	public static void main(String[] args) {
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext("movie.xml");
		MovieController movieController = (MovieController) applicationContext.getBean("moviecontroller");
		
		//take input
		Scanner input = new Scanner(System.in);
		System.out.print("Enter the movie Id: ");
		int movieId = input.nextInt();
		System.out.print("Enter the movie Name: ");
		String movieName = input.next();
		System.out.print("Enter the movie Year: ");
		int movieYear = input.nextInt();
		System.out.print("Enter the movie Duration: ");
		String duration = input.next();
		System.out.print("Enter the movie Rating: ");
		int rating = input.nextInt();
		
		//set all this things to movie object and call movie controller class
		Movie inputMovie = new Movie();
		inputMovie.setMovieId(movieId);
		inputMovie.setMovieName(movieName);
		inputMovie.setYears(movieYear);
		inputMovie.setDuration(duration);
		inputMovie.setRating(rating);
		
		//operation for save from movieController from bean we created with the input whatever we are passing
		movieController.saveMovie(inputMovie);
	}
	
}
