package com.mvc.main;
//02-16-2024, Friday
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import com.mvc.controller.MovieController;

public class CountMovieMain {

	public static void main(String[] args) {
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext("movie.xml");
		MovieController movieController = (MovieController) applicationContext.getBean("moviecontroller");
		
		Integer totalCount = movieController.countMovies();
		System.out.println("Total movies present: " + totalCount);
	}

}
