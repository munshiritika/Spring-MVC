package com.mvc.main;
//02-16-2024, Friday

import java.util.Scanner;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import com.mvc.controller.MovieController;
import com.mvc.model.Movie;

public class UpdateMovieMain {

	public static void main(String[] args) {
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext("movie.xml");
		MovieController movieController = (MovieController) applicationContext.getBean("moviecontroller");
		
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter the movie id : ");
		int id = sc.nextInt();
		System.out.print("enter the movie name : ");
		String name= sc.next();
		
		Movie updateMovieRequest = new Movie();
		updateMovieRequest.setMovieId(id);
		updateMovieRequest.setMovieName(name);
		
		movieController.updateMovie(updateMovieRequest);
	}

}
