package com.mvc.main;
//02-16-2024, Friday
import java.util.Scanner;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import com.mvc.controller.MovieController;

public class DeleteMovieByIdMain {

	public static void main(String[] args) {
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext("movie.xml");
		MovieController movieController = (MovieController) applicationContext.getBean("moviecontroller");
		
		Scanner input = new Scanner(System.in);
		System.out.print("Enter the movie Id: ");
		int id = input.nextInt();
		
		movieController.deleteMovieById(id);
	}

}
