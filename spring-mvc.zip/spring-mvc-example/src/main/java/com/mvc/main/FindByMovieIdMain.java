package com.mvc.main;
//02-15-2024, Thursday
import java.util.Scanner;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import com.mvc.controller.MovieController;
import com.mvc.model.Movie;

public class FindByMovieIdMain {

	public static void main(String[] args) {
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext("movie.xml");
		MovieController movieController = (MovieController) applicationContext.getBean("moviecontroller");
		
		Scanner input = new Scanner(System.in);
		System.out.print("Enter the movie Id to find: ");
		int movieId = input.nextInt();
		
		Movie movie = movieController.findMovieById(movieId);
		System.out.println(movie);
	}

}
