package com.mvc.controller;
//02-14-2024, Wednesday
import java.util.List;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import com.mvc.model.Movie;
import lombok.Data;

@Data
public class MovieController {
	/*
	 * MovieController - we perform all CRUD operations (like save, get, update ....)
	 * JdbcTemplate - this has methods which performs all CRUD operations to execute all queries
	 * dataSource - represents database connections properties
	 */
	private JdbcTemplate jdbcTemplate; //need to add JDBC and MYSQL dependencies in pom.xml to get this here

	//Operation 1: Save
	public void saveMovie(Movie movie) {
		//insert into movie_db.movie(movieId, movieName, years, duration, rating) values (1, "Shershah", 2019, "120 mins", 5);
		String sqlQuery = "insert into movie(movieId, movieName, years, duration, rating) values(?,?,?,?,?)";  //? acts as a placeholder
		//To add we need to create object array and then each ? will be replaced by obkect array gets.
		//pass the values from movie to the object array
		Object[] inputData = {movie.getMovieId(), movie.getMovieName(), movie.getYears(), movie.getDuration(), movie.getRating()};
		//execute the query
		jdbcTemplate.update(sqlQuery, inputData);  //update will save the query: update(query, input)
		System.out.println("Movie Saved successfully!");		
	}
	
	//Operation 2: Find Movie by Id
	public Movie findMovieById(int inputMovieId) {
		//select movieId, movieName, years, duration, rating from movie_db.movie where movieId = 2;
		String sqlQuery = "select movieId, movieName, years, duration, rating from movie where movieId = ?";
		Object[] inputId = {inputMovieId};
		Movie movieFromDatabase = jdbcTemplate.queryForObject(sqlQuery, inputId, new BeanPropertyRowMapper<Movie>(Movie.class)); //output has to be mapped by row mapper to movie class
		if(movieFromDatabase != null) {
			return movieFromDatabase;
		}
		return null;
	}
	
	//Operation 3: Find All the Movie
	public List<Movie> findAllMovie() {
		//select movieId, movieName, years, duration, rating from movie_db.movie;
		String sqlQuery = "select movieId, movieName, years, duration, rating from movie";
		List<Movie> movieListFromDatabase = jdbcTemplate.query(sqlQuery, new BeanPropertyRowMapper<Movie>(Movie.class));
		if(movieListFromDatabase.isEmpty()) {
			return null;
		}
		return movieListFromDatabase;
	}
	
	//Operation 4: Update Movie
	public void updateMovie(Movie movie) {
		//update movie_db.movie set movieId = 4 where movieName = "Hero";
		String sqlQuery = "update movie set movieId=? where movieName=?";
		Object[] inputData = {movie.getMovieId(), movie.getMovieName()};
		jdbcTemplate.update(sqlQuery, inputData);
		System.out.println("Movie Updated successfully!");	
	}
	
	//Operation 5:
	public Integer countMovies() {
		//select count(*) from movie_db.movie;
		String sqlQuery = "select count(*) from movie";
		Integer count = jdbcTemplate.queryForObject(sqlQuery, Integer.class); //output has to be mapped by row mapper to movie class
		return count;
	}
	
	//Operation 6: Delete
	public void deleteMovieById(int movieId) {
		String sqlQuery = "delete from movie where movieId=?";
		Object[] inputMovieId = {movieId};
		jdbcTemplate.update(sqlQuery, inputMovieId);
		System.out.println("Movie with Id " + movieId + " Deleted successfully!");	
	}
	
}
