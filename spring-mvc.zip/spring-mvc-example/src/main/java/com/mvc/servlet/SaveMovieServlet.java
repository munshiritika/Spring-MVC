package com.mvc.servlet;
//02-19-2024, Monday
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import com.mvc.controller.MovieController;
import com.mvc.model.Movie;

@WebServlet("/savemovie")
public class SaveMovieServlet extends HttpServlet{

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String movieId = req.getParameter("id");
		String movieName = req.getParameter("moviename");
		String year = req.getParameter("year");
		String duration = req.getParameter("duration");
		String rating = req.getParameter("rating");
		
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext("movie.xml");
		MovieController movieController = (MovieController) applicationContext.getBean("moviecontroller");
		
		Movie inputMovie = new Movie();
		inputMovie.setMovieId(Integer.parseInt(movieId));
		inputMovie.setMovieName(movieName);
		inputMovie.setYears(Integer.parseInt(year));
		inputMovie.setDuration(duration);
		inputMovie.setRating(Integer.parseInt(rating));
		
		movieController.saveMovie(inputMovie);
		req.getRequestDispatcher("SaveMovie.jsp").forward(req, resp);
		
	}
}