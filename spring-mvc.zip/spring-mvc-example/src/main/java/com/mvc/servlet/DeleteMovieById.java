package com.mvc.servlet;
//02-20-2024, Tuesday
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import com.mvc.controller.MovieController;
import com.mvc.model.Movie;

@WebServlet("/deletemoviebyid")
public class DeleteMovieById extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String movieId = req.getParameter("id");
		
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext("movie.xml");
		MovieController movieController = (MovieController) applicationContext.getBean("moviecontroller");
		
		movieController.deleteMovieById(Integer.parseInt(movieId));
		
		req.getRequestDispatcher("FindByIdMovie.jsp").forward(req, resp);
	}
	
}
