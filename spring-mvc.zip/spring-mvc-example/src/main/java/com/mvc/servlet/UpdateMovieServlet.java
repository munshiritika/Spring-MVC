package com.mvc.servlet;
//02-19-2024, Monday
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import com.mvc.controller.MovieController;
import com.mvc.model.Movie;

@WebServlet("/updatemovie")
public class UpdateMovieServlet extends HttpServlet{

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String movieId = req.getParameter("id");
		String year = req.getParameter("years");
		String duration = req.getParameter("duration");
		
		ApplicationContext applicationContext = new ClassPathXmlApplicationContext("movie.xml");
		MovieController movieController = (MovieController) applicationContext.getBean("moviecontroller");
		
		Movie inputMovie = new Movie();
		inputMovie.setMovieId(Integer.parseInt(movieId));
		inputMovie.setYears(Integer.parseInt(year));
		inputMovie.setDuration(duration);
		
		movieController.updateMovie(inputMovie);
		req.getRequestDispatcher("FindByIdMovie.jsp").forward(req, resp);
	}
}
